import java.io.*;
import java.net.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.concurrent.TimeUnit;

public class GameServer {

    private ServerSocket ss;
    private int numPlayers;
    private Socket s;
    private ServerSideConnection player1, player2;
    private Socket socket;
    private DataInputStream dataIntIn, dataDoubleIn;
    private DataOutputStream dataIntOut, dataDoubleOut;
    private int playerID;
    private double player1X = 0; //150;
    private double player2X = 0; //380;
    private double player1Y = 0; //25;
    private double player2Y = 0; //25;
    
    public GameServer() {
        System.out.println("---Game Server is Open---");
        numPlayers = 0;
        try {
            ss = new ServerSocket(1357);
        } catch(IOException ex) {
            System.out.println("IOException from GameServer constructor");
        }
    }

    public void waitForConnection() {
        try {
            System.out.println("Now accepting connections.");
            while(numPlayers < 2)
            {
                s = ss.accept();
                numPlayers++;
                System.out.println("A client has connected.");
                ServerSideConnection ssc = new ServerSideConnection(s, numPlayers);
                if(numPlayers == 1)
                {
                    player1 = ssc;
                }
                else
                {
                    player2 = ssc;
                }
                Thread t = new Thread(ssc);
                t.start();
            }
            System.out.println("We have reached the maximum amount of players.");
        } catch(IOException ex) {
            System.out.println("IOException from GameServer constructor");
        }
    }

    private class ServerSideConnection implements Runnable
    {
        public ServerSideConnection(Socket s, int id)
        {
            socket = s;
            playerID = id;
            try
            {
                dataIntIn = new DataInputStream(socket.getInputStream());
                dataIntOut = new DataOutputStream(socket.getOutputStream());
                dataDoubleIn = new DataInputStream(socket.getInputStream());
                dataDoubleOut = new DataOutputStream(socket.getOutputStream());
            } catch (IOException ex)
            {
                System.out.println("IOException from run() SSC");
            }
        }
        
        public void run()
        {
            try
            {
                dataIntOut.writeInt(playerID);
                dataIntOut.flush();
                while(true)
                {
                    playerID = dataIntIn.readInt();
                    if(playerID == 1) //imports the values from the client to the server
                    {
                        player1X = dataDoubleIn.readDouble();
                        player1Y = dataDoubleIn.readDouble();
                    }
                    else
                    {
                        player2X = dataDoubleIn.readDouble();
                        player2Y = dataDoubleIn.readDouble();
                    }
                     
                    if(playerID == 1)//imports the values from the server to the other client
                    {
                        dataDoubleOut.writeDouble(player2X);
                        dataDoubleOut.writeDouble(player2Y);
                        dataDoubleOut.flush();
                    }
                    else
                    {
                        dataDoubleOut.writeDouble(player1X);
                        dataDoubleOut.writeDouble(player1Y);
                        dataDoubleOut.flush();
                    }
                    
                    try //https://stackoverflow.com/questions/24104313/how-do-i-make-a-delay-in-java
                    {
                        Thread.sleep(20);
                    }
                    catch(InterruptedException ex)
                    {
                        Thread.currentThread().interrupt();
                    }
                    //System.out.println("Player 1 X: " + player1X + ", Y: " + player1Y + "    ---    Player 2 X: " + player2X + ", Y: " + player2Y);
                }
            } catch (IOException ex)
            {
                System.out.println("IOException from run() SSC");
            }
        }
    }
    
    public static void main(String[] args) {
        GameServer gs = new GameServer();
        gs.waitForConnection();
    }
}