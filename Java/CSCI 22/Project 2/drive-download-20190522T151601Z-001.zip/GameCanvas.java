/**
 * This is the GameCanvas class. Everything drawn on the game (the player character and the environment) is found in here.
 *
 * @authors Raymond Andrew Nojadera, Jan Arvin Petalver
 * @version 5.21.2019
 */
 
 /*
We have not discussed the Java language code 
in our program with anyone other than our instructor 
or the teaching assistants assigned to this course.

We have not used Java language code obtained 
from another student, or any other unauthorized 
source, either modified or unmodified.

If any Java language code or documentation 
used in our program was obtained from another source, 
such as a text book or webpage, those have been 
clearly noted with a proper citation in the comments 
of our code.
*/

import java.util.*;
import javax.swing.*;
import java.awt.*;
import java.awt.geom.*;

public class GameCanvas extends JComponent
{
    // instance variables
    private int width, height, playerID;
    private Color backgroundColor, otherColor;
    private ObjectInt playerHuman, playerCoop;
    private ObjectInt verticalWall1, verticalWall2, verticalWall3, verticalWall4, verticalWall5, verticalWall6, verticalWall7;
    private ObjectInt horizontalWall1, horizontalWall2, horizontalWall3, horizontalWall4, horizontalWall5, horizontalWall6, horizontalWall7, horizontalWall8;
    private ObjectInt redButton1, redButton2, blueButton1, blueButton2, exitButtonBlue, exitButtonRed;
    private ObjectInt collisionChecker, rectangleOriginal;
    private ObjectInt obstacle0, obstacle1, obstacle2, obstacle3, obstacle4, obstacle5;
    private ArrayList<ObjectInt> mapObstacles, terrain, floorButtons;
    /**
     * Constructor for objects of class GameCanvas
     */
    public GameCanvas(int w, int h, Color c, int id) // this makes all the objects on the map: its walls and the buttons, as well as the players
    {
        width = w;
        height = h;
        backgroundColor = c;
        playerID = id;
        setPreferredSize(new Dimension(width, height));
        mapObstacles = new ArrayList<>();
        terrain = new ArrayList<>();
        floorButtons = new ArrayList<>();
        
        verticalWall1 = new MapWallVertical(100, 0, 120, Color.BLACK);
        verticalWall2 = new MapWallVertical(460, 0, 120, Color.BLACK);
        verticalWall3 = new MapWallVertical(460, 120, 120, Color.BLACK);
        verticalWall4 = new MapWallVertical(100, 220, 120, Color.BLACK);
        verticalWall5 = new MapWallVertical(100, 340, 120, Color.BLACK);
        verticalWall6 = new MapWallVertical(220, 340, 120, Color.BLACK);
        verticalWall7 = new MapWallVertical(340, 340, 120, Color.BLACK);
        
        horizontalWall1 = new MapWallHorizontal(0, 220, 120, Color.BLACK);
        horizontalWall2 = new MapWallHorizontal(120, 220, 120, Color.BLACK);
        horizontalWall3 = new MapWallHorizontal(340, 220, 120, Color.BLACK);
        horizontalWall4 = new MapWallHorizontal(220, 340, 120, Color.BLACK);
        horizontalWall5 = new MapWallHorizontal(460, 340, 120, Color.BLACK);
        horizontalWall6 = new MapWallHorizontal(340, 460, 120, Color.BLACK);
        horizontalWall7 = new MapWallHorizontal(120, 100, 120, Color.BLACK);
        horizontalWall8 = new MapWallHorizontal(340, 100, 120, Color.BLACK);
        
        blueButton1 = new Button(30, 30, 40, Color.BLUE);
        redButton1 = new Button(520, 30, 40, Color.RED);
        blueButton2 = new Button(270, 390, 40, Color.BLUE);
        redButton2 = new Button(520, 390, 40, Color.RED);
        exitButtonBlue = new Button(30, 270, 40, Color.CYAN);
        exitButtonRed = new Button(30, 390, 40, Color.PINK);
        
        obstacle0 = new MapWallVertical(220, 110, 120, Color.BLUE);
        obstacle1 = new MapWallVertical(340, 230, 120, Color.BLUE);
        obstacle2 = new MapWallHorizontal(100, 460, 140, Color.RED);
        obstacle3 = new MapWallVertical(460, 360, 120, Color.MAGENTA);
        obstacle4 = new MapWallHorizontal(0,350, 120, Color.RED);
        
        //put in map obstacles here

        terrain.add(verticalWall1);
        terrain.add(verticalWall2);
        terrain.add(verticalWall3);
        terrain.add(verticalWall4);
        terrain.add(verticalWall5);
        terrain.add(verticalWall6);
        terrain.add(verticalWall7);
        terrain.add(horizontalWall1);
        terrain.add(horizontalWall2);
        terrain.add(horizontalWall3);
        terrain.add(horizontalWall4);
        terrain.add(horizontalWall5);
        terrain.add(horizontalWall6);
        terrain.add(horizontalWall7);
        terrain.add(horizontalWall8);
        
        floorButtons.add(blueButton1);
        floorButtons.add(redButton1);
        floorButtons.add(blueButton2);
        floorButtons.add(redButton2);
        floorButtons.add(exitButtonBlue);
        floorButtons.add(exitButtonRed);
        
        mapObstacles.add(obstacle0);
        mapObstacles.add(obstacle1);
        mapObstacles.add(obstacle2);
        mapObstacles.add(obstacle3);
        mapObstacles.add(obstacle4);
        
        playerHuman = new Player(150, 25, 50, Color.BLUE);
        playerCoop = new Player(380, 25, 50, Color.RED);
        
    }
    
    /**
     * An example of a method - replace this comment with your own
     *
     * @param  y  a sample parameter for a method
     * @return    the sum of x and y
     */
    @Override
    protected void paintComponent(Graphics g)
    {
        Graphics2D g2d = (Graphics2D) g;
        
        RenderingHints rh = new RenderingHints(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2d.setRenderingHints(rh);
        
        Rectangle2D background = new Rectangle2D.Double(0,0,width,height);
        g2d.setPaint(backgroundColor);
        g2d.fill(background);
        
        for(int i = 0; i<mapObstacles.size(); i++)
        {
            mapObstacles.get(i).draw(g2d);
        }
        
        for(int i = 0; i<terrain.size(); i++)
        {
            terrain.get(i).draw(g2d);
        }
        
        for(int i = 0; i<floorButtons.size(); i++)
        {
            floorButtons.get(i).draw(g2d);
        }
        
        playerHuman.draw(g2d);
        playerCoop.draw(g2d);
    }
    
    public ObjectInt getPlayer() // this is to determine if the user is player 1
    {
        if(playerID == 1)
        {
            return playerHuman;
        }
        else
        {
            return playerCoop;
        }
    }
    
    public ObjectInt getObstacle(int i) // this is to make the door obstacles
    {
        return mapObstacles.get(i);
    }
    
    public ObjectInt getButton(int i) // this is to make the buttons to step on
    {
        return floorButtons.get(i);
    }
    
    public ObjectInt getCoopPlayer() // this is to determine if the user is player 2
    {
        if(playerID == 1)
        {
            return playerCoop;
        }
        else
        {
            return playerHuman;
        }
    }
    
    public ObjectInt getGoal(int i) // this is to make the respective exits for the players
    {
        if(i == 1)
        {
            return exitButtonBlue;
        }
        else
        {
            return exitButtonRed;
        }
    }
}
