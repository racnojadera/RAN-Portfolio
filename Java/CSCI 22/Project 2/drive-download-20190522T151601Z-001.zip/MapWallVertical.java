
/**
 * Write a description of class Player here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */

import java.awt.*;
import java.awt.geom.*;

public class MapWallVertical implements ObjectInt
{
    // instance variables - replace the example below with your own
    private double x, y, size, width, height, degrees;
    private Color color;

    /**
     * Constructor for objects of class MapWallVertical
     */
    public MapWallVertical(double x, double y, double s, Color c)
    {
        this.x = x;
        this.y = y;
        //orig x y = reference point to stop timer, save ram
        size = s;
        width = s/6;
        height = s;
        degrees = 0;
        color = c;
    }
    
    public void draw(Graphics2D g2d)
    {
        g2d.rotate(Math.toRadians(degrees), x, y);
        Rectangle2D.Double wall = new Rectangle2D.Double(x, y, width, height);
        
        g2d.setColor(color);
        g2d.fill(wall);
    }
    
    public void adjustX(double xDistance)
    {
        x += xDistance;
    }
    
    public void adjustY(double xDistance)
    {
        y += xDistance;
    }
    
    public void adjustRotation(double degrees)
    {
        this.degrees += degrees;
    }
    
    public double getX()
    {
        return x;
    }
     
    public double getY()
    {
        return y;
    }
    
    public double getWidth()
    {
        return width;
    }
    
    public double getHeight()
    {
        return height;
    }
    
    public double getSize()
    {
        return size;
    }
    
    public Color getColor()
    {
        return color;
    }
    
    public void setX(double d)
    {
        x = d;
    }
    
    public void setY(double d)
    {
        y = d;
    }
    
}
