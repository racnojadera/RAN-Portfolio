
/**
 * This is the Button class. This is the object template for the buttons in the game. It removes the obstacles.
 * @authors Raymond Andrew Nojadera, Jan Arvin Petalver
 * @version 5.21.2019
 */
 
 /*
We have not discussed the Java language code 
in our program with anyone other than our instructor 
or the teaching assistants assigned to this course.

We have not used Java language code obtained 
from another student, or any other unauthorized 
source, either modified or unmodified.

If any Java language code or documentation 
used in our program was obtained from another source, 
such as a text book or webpage, those have been 
clearly noted with a proper citation in the comments 
of our code.
*/

import java.awt.*;
import java.awt.geom.*;

public class Button implements ObjectInt
{
    // instance variables
    private double x, y, size, width, height, degrees;
    private Color color;

    /**
     * Constructor for objects of class Player
     */
    public Button(double x, double y, double s, Color c)
    {
        this.x = x;
        this.y = y;
        //orig x y = reference point to stop timer, save ram
        size = s;
        width = s;
        height = s;
        degrees = 0;
        color = c;
    }
    
    public void draw(Graphics2D g2d) // this draws the button object
    {
        g2d.rotate(Math.toRadians(degrees), x, y);
        Rectangle2D.Double button = new Rectangle2D.Double(x, y, width, height);
        
        g2d.setColor(color);
        g2d.fill(button);
    }
    
    public void adjustX(double xDistance) // it adds the perimeter to the current value of x
    {
        x += xDistance;
    }
    
    public void adjustY(double xDistance) // to adds the perimeter to the current value of y
    {
        y += xDistance;
    }
    
    public void adjustRotation(double degrees) // it adjusts the rotation of the object
    {
        this.degrees += degrees;
    }
    
    public double getX() // it gets the x-coordinate of an object
    {
        return x;
    }
    
    public double getY() // it gets the y-coordinate of an object
    {
        return y;
    }
    
    public double getWidth() // it gets the width of an object
    {
        return width;
    }
    
    public double getHeight() // it gets the height of an object
    {
        return height;
    }
    
    public double getSize() // it gets the size of an object
    {
        return size;
    }
    
    public Color getColor() // it gets the color of an object
    {
        return color;
    }
    
    public void setX(double d) // it sets the x value to a specific x-coordinate
    {
        x = d;
    }
    
    public void setY(double d) // it sets the y value to a specific y-coordinate
    {
        y = d;
    }
}
