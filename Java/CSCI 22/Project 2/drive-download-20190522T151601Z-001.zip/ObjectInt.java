
/**
 * Write a description of class ObjectInt here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */

import java.awt.*;
import java.awt.geom.*;

public interface ObjectInt
{
    void draw(Graphics2D g2d);
    void adjustX(double xDistance);
    void adjustY(double xDistance);
    void adjustRotation(double degrees);
    double getX();
    double getY();
    double getWidth();
    double getHeight();
    double getSize();
    void setX(double d);
    void setY(double d);
    Color getColor();
}
