
/**
 * This is the GameFrame class. It contains the main JFrame for the game. The players' actions can also be found here.
 *
 * @authors Raymond Andrew Nojadera, Jan Arvin Petalver
 * @version 5.21.2019
 */
 
 /*
We have not discussed the Java language code 
in our program with anyone other than our instructor 
or the teaching assistants assigned to this course.

We have not used Java language code obtained 
from another student, or any other unauthorized 
source, either modified or unmodified.

If any Java language code or documentation 
used in our program was obtained from another source, 
such as a text book or webpage, those have been 
clearly noted with a proper citation in the comments 
of our code.
*/

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class GameFrame extends JFrame
{
    private int width, height, goingUp, goingDown, goingLeft, goingRight;
    private String title;
    private JPanel contentPane;
    private GameCanvas gameCanvas;
    private GameTimer gameTimer;
    
    /**
     * Constructor for objects of class GameFrame
     */
    public GameFrame(int w, int h, String t)
    {
        width = w;
        height = h;
        title = t;
    }

    public void setUpGUI(int id)
    {
        contentPane = (JPanel) getContentPane();
        contentPane.setFocusable(true);
        gameCanvas = new GameCanvas(width, height, Color.WHITE, id);
        gameTimer = new GameTimer(gameCanvas);
        gameTimer.setUpTimer();
        addKeyBindings();
        add(gameCanvas);
        setTitle(title);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        pack();
        setVisible(true);
    }
    
    public void addKeyBindings() //https://stackoverflow.com/questions/752999/how-do-i-handle-simultaneous-key-presses-in-java
    {
        goingUp = 0;
        goingDown = 0;
        goingLeft = 0;
        goingRight = 0;
        ActionMap am = contentPane.getActionMap();
        InputMap im = contentPane.getInputMap();
        am.put("UP1", goUP);
        am.put("DOWN1", goDown);
        am.put("LEFT1", goLeft);
        am.put("RIGHT1", goRight);
        im.put(KeyStroke.getKeyStroke(KeyEvent.VK_UP, 0, false), "UP1");
        im.put(KeyStroke.getKeyStroke(KeyEvent.VK_DOWN, 0, false), "DOWN1");
        im.put(KeyStroke.getKeyStroke(KeyEvent.VK_LEFT, 0, false), "LEFT1");
        im.put(KeyStroke.getKeyStroke(KeyEvent.VK_RIGHT, 0, false), "RIGHT1");
        am.put("UP0", goUP2);
        am.put("DOWN0", goDown2);
        am.put("LEFT0", goLeft2);
        am.put("RIGHT0", goRight2);
        im.put(KeyStroke.getKeyStroke(KeyEvent.VK_UP, 0, true), "UP0");
        im.put(KeyStroke.getKeyStroke(KeyEvent.VK_DOWN, 0, true), "DOWN0");
        im.put(KeyStroke.getKeyStroke(KeyEvent.VK_LEFT, 0, true), "LEFT0");
        im.put(KeyStroke.getKeyStroke(KeyEvent.VK_RIGHT, 0, true), "RIGHT0");
    }
    
    AbstractAction goUP = new AbstractAction()
    {
        public void actionPerformed(ActionEvent ae)
        {
            gameTimer.adjustUp(1);
        }
    };
    
    AbstractAction goDown = new AbstractAction()
    {
        public void actionPerformed(ActionEvent ae)
        {
            gameTimer.adjustDown(1);
        }
    };
    
    AbstractAction goLeft = new AbstractAction()
    {
        public void actionPerformed(ActionEvent ae)
        {
            gameTimer.adjustLeft(1);
        }
    };
    
    AbstractAction goRight = new AbstractAction()
    {
        public void actionPerformed(ActionEvent ae)
        {
            gameTimer.adjustRight(1);
        }
    };
    
    AbstractAction goUP2 = new AbstractAction()
    {
        public void actionPerformed(ActionEvent ae)
        {
            gameTimer.adjustUp(0);
        }
    };
    
    AbstractAction goDown2 = new AbstractAction()
    {
        public void actionPerformed(ActionEvent ae)
        {
            gameTimer.adjustDown(0);
        }
    };
    
    AbstractAction goLeft2 = new AbstractAction()
    {
        public void actionPerformed(ActionEvent ae)
        {
            gameTimer.adjustLeft(0);
        }
    };
    
    AbstractAction goRight2 = new AbstractAction()
    {
        public void actionPerformed(ActionEvent ae)
        {
            gameTimer.adjustRight(0);
        }
    };
    
    public GameCanvas getCanvas()
    {
        return gameCanvas;
    }
    
    public GameTimer getTimer()
    {
        return gameTimer;
    }
}
