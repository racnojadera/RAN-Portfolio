
/**
 * Write a description of class GameStarter here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */

import java.io.*;
import java.net.*;
import java.util.*;
import javax.swing.*;

public class GameStarter
{
    private ClientSideConnection csc;
    private int playerID;
    private double otherPlayerX, otherPlayerY;
    private GameFrame f;
    private Socket socket;
    private DataInputStream dataIntIn, dataDoubleIn;
    private DataOutputStream dataIntOut, dataDoubleOut;
    private GameTimer gameTimer;
    
    public void connectToServer()
    {
        csc = new ClientSideConnection();
    }
    
    private class ClientSideConnection
    {
        public ClientSideConnection()
        {
            System.out.println("---Client---");
            try
            {
                socket = new Socket("localhost", 1357);
                dataIntIn = new DataInputStream(socket.getInputStream());
                dataIntOut = new DataOutputStream(socket.getOutputStream());
                dataDoubleIn = new DataInputStream(socket.getInputStream());
                dataDoubleOut = new DataOutputStream(socket.getOutputStream());
                
                playerID = dataIntIn.readInt();
                System.out.println("Connected to server as Player " + playerID + ".");
                
                f = new GameFrame(580, 580, "Shapes Escape");
                f.setUpGUI(playerID);
                sendToServer sTS = new sendToServer();
                sTS.start();
            } catch (IOException ex)
            {
                System.out.println("IO Exception from CSC constructor");
            }
        }
        
        public void sendLocationServer()
        {
            try
            {
                double playerX = f.getCanvas().getPlayer().getX();
                double playerY = f.getCanvas().getPlayer().getY();
                dataDoubleOut.writeDouble(playerX);
                dataDoubleOut.writeDouble(playerY);
                //dataDoubleOut.flush();
                System.out.println("X: " + playerX + ", Y: " + playerY);
            }
            catch (IOException ex)
            {
                System.out.println("IOException from sendLocationServer() CSC");
            }
        }
    }
    
    private class sendToServer extends Thread
    {
        @Override
        public void run()
        {
            try
            {
                while(true)
                {
                    dataIntOut.writeInt(playerID);
                    double playerX = f.getCanvas().getPlayer().getX();
                    double playerY = f.getCanvas().getPlayer().getY();
                    dataDoubleOut.writeDouble(playerX);
                    dataDoubleOut.writeDouble(playerY);
                    dataIntOut.flush();
                    dataDoubleOut.flush();
                    //System.out.println("X: " + playerX + ", Y: " + playerY);
                }   
            }
            catch (IOException ex)
            {
                System.out.println("IOException from sendLocationServer() CSC");
            }
            
            try
            {
                double otherPlayerX = dataDoubleIn.readDouble();
                double otherPlayerY = dataDoubleIn.readDouble();
                //System.out.println(otherPlayerX + " " + otherPlayerY + " " + playerID);
                if(playerID == 1)
                {
                    gameTimer.adjustP2(otherPlayerX, otherPlayerY);
                }
                else
                {
                    gameTimer.adjustP1(otherPlayerX, otherPlayerY);
                }
            }
            catch (IOException ex)
            {
                System.out.println("IOException from receiveLocationServer() CSC");
            }
        }
    }
    
    public static void main(String[] args)
    {
        GameStarter gs = new GameStarter();
        gs.connectToServer();
    }
}
