/**
 * This is the GameTimer class. Depending on how the player interacts with the environment, this sets the timer for the game.
 *
 * @authors Raymond Andrew Nojadera, Jan Arvin Petalver
 * @version 5.21.2019
 */
 
 /*
We have not discussed the Java language code 
in our program with anyone other than our instructor 
or the teaching assistants assigned to this course.

We have not used Java language code obtained 
from another student, or any other unauthorized 
source, either modified or unmodified.

If any Java language code or documentation 
used in our program was obtained from another source, 
such as a text book or webpage, those have been 
clearly noted with a proper citation in the comments 
of our code.
*/

import javax.swing.*;
import java.awt.event.*;

public class GameTimer implements ActionListener
{
    private int up, down, left, right, uplim, downlim, leftlim, rightlim, but1, but2, but3, but4;
    private double player1X, player1Y, player2X, player2Y;
    private String locationTemplate;
    private Timer timer;
    private boolean collisionDetector;
    private ActionListener timerCount;
    private GameCanvas gCanvas;
    private ObjectInt player1, player2;
    
    /**
     * Constructor for objects of class GameTimer
     */
    public GameTimer(GameCanvas gc)
    {
        up = 0;
        down = 0;
        left = 0;
        right = 0;
        uplim = 0;
        downlim = 0;
        leftlim = 0;
        rightlim = 0;
        but1 = 0;
        but2 = 0;
        but3 = 0;
        but4 = 0;
        locationTemplate = "";
        gCanvas = gc;
        player1 = gCanvas.getPlayer();
        player2 = gCanvas.getCoopPlayer();
    }
    
    public void setUpTimer()
    {
        timer = new Timer(20, this);
        timer.setRepeats(true);
        timer.start();
    }
    
    public void actionPerformed(ActionEvent e)
    {
        move();
        locationChecker();
        movementChecker();
        checkSteppingButton();
        checkGame();
    }
    
    public void move() // to move to the corresponding direction if the user wants the character to go a specific direction
    {
        if((up != 0) && (down == 0) && (uplim == 0))
        {
            if((left != 0) && (right == 0) && (leftlim == 0))
            {
                player1.adjustX(-2*Math.sqrt(3));
                player1.adjustY(-2*Math.sqrt(3));
            }
            
            else if((right != 0) && (left == 0) && (rightlim == 0))
            {
                player1.adjustX(2*Math.sqrt(3));
                player1.adjustY(-2*Math.sqrt(3));
            }
            
            else
            {
                player1.adjustY(-3);
            }
        }
        
        else if((down != 0) && (up == 0) && (downlim == 0))
        {
            if((left != 0) && (right == 0) && (leftlim == 0))
            {
                player1.adjustX(-2*Math.sqrt(3));
                player1.adjustY(2*Math.sqrt(3));
            }
            
            else if((right != 0) && (left == 0) && (rightlim == 0))
            {
                player1.adjustX(2*Math.sqrt(3));
                player1.adjustY(2*Math.sqrt(3));
            }
            
            else
            {
                player1.adjustY(3);
            }
        }
        
        else if((right != 0) && (left == 0) && (rightlim == 0))
        {
            player1.adjustX(3);
        }
        
        else if((left != 0) && (right == 0) && (leftlim == 0))
        {
            player1.adjustX(-3);
        }

        gCanvas.repaint();
    }
    
    public ObjectInt getPlayer()
    {
        return player1;
    }
    
    public void adjustUp(int value) // to adjust whether the button is pressed or not
    {
        up = value;
    }
    
    public void adjustDown(int value) // to adjust whether the button is pressed or not
    {
        down = value;
    }
    
    public void adjustLeft(int value) // to adjust whether the button is pressed or not
    {
        left = value;
    }
    
    public void adjustRight(int value) // to adjust whether the button is pressed or not
    {
        right = value;
    }
    
    public void locationChecker() // partitions the map into a 5x5 grid; it allows collision detection 
    {
        double playerLocX = player1.getX();// + player1.getWidth()*0.5;
        double playerLocY = player1.getY();// + player1.getWidth()*0.5;
        
        if((playerLocY >= 0) && (playerLocY < 100))
        {
            if((playerLocX >= 0) && (playerLocX < 100))
            {
                locationTemplate = "I";
            }
            else if((playerLocX >= 120) && (playerLocX < 220))
            {
                locationTemplate = "J";
            }
            else if((playerLocX >= 240) && (playerLocX < 340))
            {
                locationTemplate = "A";
            }
            else if((playerLocX >= 360) && (playerLocX < 460))
            {
                locationTemplate = "L";
            }
            else if((playerLocX >= 480) && (playerLocX < 580))
            {
                locationTemplate = "I";
            }
        }
        else if((playerLocY >= 120) && (playerLocY < 220))
        {
            if((playerLocX >= 0) && (playerLocX < 120))
            {
                locationTemplate = "D";
            }
            else if((playerLocX >= 120) && (playerLocX < 220))
            {
                locationTemplate = "H";
                checkPassableObstacle();
            }
            else if((playerLocX >= 240) && (playerLocX < 340))
            {
                locationTemplate = "M";
                checkPassableObstacle();
            }
            else if((playerLocX >= 360) && (playerLocX < 460))
            {
                locationTemplate = "L";
            }
            else if((playerLocX >= 480) && (playerLocX < 580))
            {
                locationTemplate = "G";
            }
        }
        else if((playerLocY >= 240) && (playerLocY < 340))
        {
            if((playerLocX >= 0) && (playerLocX < 100))
            {
                locationTemplate = "I";
                checkPassableObstacle();
            }
            else if((playerLocX >= 120) && (playerLocX < 220))
            {
                locationTemplate = "N";
            }
            else if((playerLocX >= 240) && (playerLocX < 340))
            {
                locationTemplate = "C";
                checkPassableObstacle();
            }
            else if((playerLocX >= 360) && (playerLocX < 460))
            {
                locationTemplate = "A";
                checkPassableObstacle();
            }
            else if((playerLocX >= 480) && (playerLocX + player1.getWidth() < 580))
            {
                locationTemplate = "E";
            }
        }
        else if((playerLocY >= 360) && (playerLocY < 460))
        {
            if((playerLocX >= 0) && (playerLocX < 100))
            {
                locationTemplate = "G";
                checkPassableObstacle();
            }
            else if((playerLocX >= 120) && (playerLocX < 220))
            {
                locationTemplate = "G";
                checkPassableObstacle();
            }
            else if((playerLocX >= 240) && (playerLocX < 340))
            {
                locationTemplate = "I";
            }
            else if((playerLocX >= 360) && (playerLocX < 460))
            {
                locationTemplate = "D";
                checkPassableObstacle();
            }
            else if((playerLocX >= 480) && (playerLocX < 580))
            {
                locationTemplate = "F";
                checkPassableObstacle();
            }
        }
        else if((playerLocY >= 480) && (playerLocY < 580))
        {
            if((playerLocX >= 0) && (playerLocX < 100))
            {
                locationTemplate = "D";
            }
            else if((playerLocX >= 120) && (playerLocX < 220))
            {
                locationTemplate = "C";
                checkPassableObstacle();
            }
            else if((playerLocX >= 240) && (playerLocX < 340))
            {
                locationTemplate = "C";
            }
            else if((playerLocX >= 360) && (playerLocX < 460))
            {
                locationTemplate = "H";
            }
            else if((playerLocX >= 480) && (playerLocX < 580))
            {
                locationTemplate = "E";
            }
        }
    }
    
    public void movementChecker() // to know where the character is moving
    {
        uplim = 0;
        downlim = 0;
        leftlim = 0;
        rightlim = 0;
        
        double playerLocX = player1.getX()%120;
        double playerLocY = player1.getY()%120;

        switch(locationTemplate)
        {
            case "A":
                if(playerLocY <= 3)
                {
                    uplim = 1;
                }
                break;
                
            case "B":
                if(playerLocX <= 3)
                {
                    leftlim = 1;
                }
                break;
                
            case "C":
                if(playerLocY + player1.getHeight() >= 97)
                {
                    downlim = 1;
                }
                break;
                
            case "D":
                if(playerLocX <= 3)
                {
                    leftlim = 1;
                }
                if(playerLocY + player1.getHeight() >= 97)
                {
                    downlim = 1;
                }
                break;
                
            case "E":
                if(playerLocX>= 97)
                {
                    rightlim = 1;
                }
                if(playerLocY + player1.getHeight() >= 97)
                {
                    downlim = 1;
                }
                break;
                
            case "F":
                if(playerLocY <= 3)
                {
                    uplim = 1;
                }
                if(playerLocX + player1.getWidth() >= 97)
                {
                    rightlim = 1;
                }
                break;
                
            case "G":
                if(playerLocX <= 3)
                {
                    leftlim = 1;
                }
                if(playerLocX + player1.getWidth() >= 97)
                {
                    rightlim = 1;
                }
                break;
                
            case "H":
                if(playerLocY <= 3)
                {
                    uplim = 1;
                }
                if(playerLocY + player1.getHeight() >= 97)
                {
                    downlim = 1;
                }
                break;
                
            case "I":
                if(playerLocX <= 3)
                {
                    leftlim = 1;
                }
                if(playerLocX + player1.getWidth() >= 97)
                {
                    rightlim = 1;
                }
                if(playerLocY <= 3)
                {
                    uplim = 1;
                }
                break;
                
            case "J":
                if(playerLocY <= 3)
                {
                    uplim = 1;
                }
                if(playerLocX <= 3)
                {
                    leftlim = 1;
                }
                if(playerLocY + player1.getHeight() >= 97)
                {
                    downlim = 1;
                }
                break;
                
            case "K":
                if(playerLocX <= 3)
                {
                    leftlim = 1;
                }
                if(playerLocY + player1.getHeight() >= 97)
                {
                    downlim = 1;
                }
                if(playerLocX + player1.getWidth() >= 97)
                {
                    rightlim = 1;
                }
                break;
                
            case "L":
                if(playerLocY + player1.getHeight() >= 97)
                {
                    downlim = 1;
                }
                if(playerLocX + player1.getWidth() >= 97)
                {
                    rightlim = 1;
                }
                if(playerLocY <= 3)
                {
                    uplim = 1;
                }
                break; 

            case "N":
                if(playerLocY <= 3)
                {
                    uplim = 1;
                }
                if(playerLocX <= 3)
                {
                    leftlim = 1;
                }
                break;
                
            case "O":
                if(playerLocY + player1.getHeight() >= 97)
                {
                    downlim = 1;
                }
                if(playerLocX + player1.getWidth() >= 97)
                {
                    rightlim = 1;
                }
                if(playerLocY <= 3)
                {
                    uplim = 1;
                }
                if(playerLocX <= 3)
                {
                    leftlim = 1;
                }
        }   
    }
    //button step
    
    public void checkSteppingButton() // to check if the button is stepped on
    {
        double playerLocX = player1.getX();
        double playerLocY = player1.getY();
        if((playerLocX >= 0) && (playerLocX < 100) && (playerLocY >= 0) && (playerLocY < 100))
        {
            ObjectInt tempButton = gCanvas.getButton(0);
            if(((playerLocX + player1.getWidth() > tempButton.getX()) || (playerLocX < tempButton.getX() + tempButton.getWidth())) && (but1 == 0))
            {
                if((playerLocY + player1.getHeight() > tempButton.getY()) || (playerLocY < tempButton.getX() + tempButton.getHeight()))
                {
                    if((player1.getColor().getRGB() == tempButton.getColor().getRGB()))
                    {
                        gCanvas.getObstacle(1).adjustX(1000);
                        but1 = 1;
                    }
                }
            }
        }
        else if((playerLocX >= 480) && (playerLocX < 580) && (playerLocY >= 0) && (playerLocY < 100))
        {
            ObjectInt tempButton = gCanvas.getButton(1);
            if((playerLocX + player1.getWidth() > tempButton.getX()) || (playerLocX < tempButton.getX() + tempButton.getWidth()))
            {
                if((playerLocY + player1.getHeight() > tempButton.getY()) || (playerLocY < tempButton.getX() + tempButton.getHeight()))
                {
                    if((player1.getColor().getRGB() == tempButton.getColor().getRGB()) && (but2 == 0))
                    {
                        gCanvas.getObstacle(2).adjustX(1000);
                        but2 = 1;
                    }
                }
            }
        }
        else if((playerLocX >= 240) && (playerLocX < 340) && (playerLocY >= 360) && (playerLocY < 460))
        {
            ObjectInt tempButton = gCanvas.getButton(2);
            if((playerLocX + player1.getWidth() > tempButton.getX()) || (playerLocX < tempButton.getX() + tempButton.getWidth()))
            {
                if((playerLocY + player1.getHeight() > tempButton.getY()) || (playerLocY < tempButton.getX() + tempButton.getHeight()))
                {
                    if((player1.getColor().getRGB() == tempButton.getColor().getRGB()) && (but3 == 0))
                    {
                        gCanvas.getObstacle(3).adjustX(1000);
                        but3 = 1;
                    }
                }
            }
        }
        else if((playerLocX >= 480) && (playerLocX < 580) && (playerLocY >= 360) && (playerLocY < 460))
        {
            ObjectInt tempButton = gCanvas.getButton(3);
            if((playerLocX + player1.getWidth() > tempButton.getX()) || (playerLocX < tempButton.getX() + tempButton.getWidth()))
            {
                if((playerLocY + player1.getHeight() > tempButton.getY()) || (playerLocY < tempButton.getX() + tempButton.getHeight()))
                {
                    if((player1.getColor().getRGB() == tempButton.getColor().getRGB()) && (but4 == 0))
                    {
                        gCanvas.getObstacle(4).adjustX(1000);
                        but4 = 1;
                    }
                }
            }
        }
        else
        {
            if(but1 == 1)
            {
                gCanvas.getObstacle(1).adjustX(-1000);
                but1 = 0;
            }
            else if(but2 == 1)
            {
                gCanvas.getObstacle(2).adjustX(-1000);
                but2 = 0;
            }
            else if(but3 == 1)
            {
                gCanvas.getObstacle(3).adjustX(-1000);
                but3 = 0;
            }
            else if(but4 == 1)
            {
                gCanvas.getObstacle(4).adjustX(-1000);
                but4 = 0;
            }
        }
        
        
    }
    
    public void checkPassableObstacle() //https://stackoverflow.com/questions/15262258/how-could-i-compare-colors-in-java
    {
        double playerLocX = player1.getX();// + player1.getWidth()*0.5;
        double playerLocY = player1.getY();
        
        if((playerLocY >= 120) && (playerLocY < 220) && (playerLocX >= 117) && (playerLocX < 241) && (gCanvas.getObstacle(0).getX() == 220.00))
        {
            if(player1.getColor().getRGB() != gCanvas.getObstacle(0).getColor().getRGB())
            {
                locationTemplate = "L";
            }
            else
            {
                locationTemplate = "H";
            }
        }
        else if((playerLocY >= 120) && (playerLocY < 220) && (playerLocX <= 243) && (playerLocX >= 221) && (gCanvas.getObstacle(0).getX() == 220.00))
        {
            if(player1.getColor().getRGB() != gCanvas.getObstacle(0).getColor().getRGB())
            {
                locationTemplate = "B";
            }
            else
            {
                locationTemplate = "M";
            }
        }
        if((playerLocY >= 240) && (playerLocY < 340) && (playerLocX >= 237) && (playerLocX < 361) && (gCanvas.getObstacle(1).getX() == 340.00))
        {
            if(player1.getColor().getRGB() != gCanvas.getObstacle(1).getColor().getRGB())
            {
                locationTemplate = "E";
            }
            else
            {
                locationTemplate = "C";
            }
        }
        else if((playerLocY >= 240) && (playerLocY < 340) && (playerLocX <= 363) && (playerLocX >= 341) && (gCanvas.getObstacle(1).getX() == 340.00))
        {
            if(player1.getColor().getRGB() != gCanvas.getObstacle(1).getColor().getRGB())
            {
                locationTemplate = "N";
            }
            else
            {
                locationTemplate = "A";
            }
        }
        if((playerLocX >= 120) && (playerLocX < 220) && (playerLocY >= 457) && (playerLocY < 481) && (gCanvas.getObstacle(2).getY() == 460.00))
        {
            if(player1.getColor().getRGB() != gCanvas.getObstacle(2).getColor().getRGB())
            {
                locationTemplate = "K";
            }
            else
            {
                locationTemplate = "G";
            }
        }
        else if((playerLocX >= 120) && (playerLocX < 220) && (playerLocY >= 461) && (playerLocY < 483) && (gCanvas.getObstacle(2).getY() == 460.00))
        {
            if(player1.getColor().getRGB() != gCanvas.getObstacle(2).getColor().getRGB())
            {
                locationTemplate = "H";
            }
            else
            {
                locationTemplate = "C";
            }
        }
        if((playerLocY >= 360) && (playerLocY < 480) && (playerLocX >= 357) && (playerLocX < 481) && (gCanvas.getObstacle(3).getX() == 460.00))
        {
            if(player1.getColor().getRGB() != gCanvas.getObstacle(3).getColor().getRGB())
            {
                locationTemplate = "K";
            }
            else
            {
                locationTemplate = "D";
            }
        }
        else if((playerLocY >= 360) && (playerLocY < 460) && (playerLocX <= 483) && (playerLocX >= 461) && (gCanvas.getObstacle(3).getX() == 460.00))
        {
            if(player1.getColor().getRGB() != gCanvas.getObstacle(3).getColor().getRGB())
            {
                locationTemplate = "I";
            }
            else
            {
                locationTemplate = "F";
            }
        }
        if((playerLocX >= 0) && (playerLocX < 100) && (playerLocY >= 337) && (playerLocY < 361) && (gCanvas.getObstacle(4).getY() == 350.00))
        {
            if(player1.getColor().getRGB() != gCanvas.getObstacle(4).getColor().getRGB())
            {
                locationTemplate = "O";
            }
            else
            {
                locationTemplate = "I";
            }
        }
        else if((playerLocX >= 0) && (playerLocX < 100) && (playerLocY >= 337) && (playerLocY < 363) && (gCanvas.getObstacle(4).getY() == 350.00))
        {
            if(player1.getColor().getRGB() != gCanvas.getObstacle(4).getColor().getRGB())
            {
                locationTemplate = "I";
            }
            else
            {
                locationTemplate = "G";
            }
        }
    }
    
    public void adjustP1(double x, double y) // to get the x and y coordinates of player 1
    {
        player1.setX(x);
        player1.setY(y);
    }
    
    public void adjustP2(double x, double y) // to get the x and y coordinates of player 2
    {
        player2.setX(x);
        player2.setY(y);
    }
    
    public void checkGame() // to check if the players won the game
    {
        int winBlue = 0;
        int winRed = 0;
        if ((player1.getX()+player1.getWidth() >= gCanvas.getGoal(1).getX()) && (gCanvas.getGoal(1).getX() + gCanvas.getGoal(1).getWidth() >= player1.getX()))
        {
            if((player1.getY() + player1.getHeight() >= gCanvas.getGoal(1).getY()) && (gCanvas.getGoal(1).getX() + gCanvas.getGoal(1).getWidth() >= player1.getY()))
            {
                winBlue = 1;
            }
        }
        else
        {
            winBlue = 0;
        }
        if ((player2.getX()+player2.getWidth() >= gCanvas.getGoal(2).getX()) && (gCanvas.getGoal(2).getX() + gCanvas.getGoal(2).getWidth() >= player2.getX()))
        {
            if((player2.getY() + player2.getHeight() >= gCanvas.getGoal(2).getY()) && (gCanvas.getGoal(2).getX() + gCanvas.getGoal(2).getWidth() >= player2.getY()))
            {
                winRed = 1;
            }
        }
        else
        {
            winRed = 0;
        }
        
        if((winBlue == 1) && (winRed == 1))
        {
            System.out.println("YOU WIN");
        }
    }
}
