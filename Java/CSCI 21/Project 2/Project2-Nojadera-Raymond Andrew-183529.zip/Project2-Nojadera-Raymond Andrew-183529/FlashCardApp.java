
/**
 * Runs the actual program.
 *
 * @author Raymond Andrew C. Nojadera
 * @version December 8, 2018
 */

import java.util.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class FlashCardApp
{
    /**
     * The method that initializes the program.
     * 
     * @param data initializes Database contents into the GUI.
     */
    public static void main(String[] args)
    {
        Database data = new Database();
        JFrame mainMenu = new FlashCardGUI(data);
        mainMenu.setSize(480,300);
        mainMenu.setTitle("Flash Card Application");
        mainMenu.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        mainMenu.setVisible(true);
    }
}
