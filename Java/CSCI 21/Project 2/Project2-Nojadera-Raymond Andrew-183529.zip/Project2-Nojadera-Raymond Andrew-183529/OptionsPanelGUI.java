
/**
 * Interface that contains the save/load function, as well as the difficulty adjustment (practice, identification(easy), identification(hard)).
 *
 * @author Raymond Andrew C. Nojadera
 * @version December 8, 2018
 */

import java.io.*;
import java.util.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class OptionsPanelGUI extends JFrame
{
    private Database data;
    private JButton importFile, exportFile, difficulty1, difficulty2, difficulty3, backMain;
    private JTextField importFileName, exportFileName;
    private JLabel titleMenu, importFileLabel, exportFileLabel, difficultyLabel;
    private JPanel centerArea, bottomArea;
    private GridBagConstraints centerStage;

    /**
     * Contains the contents of the interface
     *
     * @param data loads the Database's data
     */
    public OptionsPanelGUI(Database data)
    {
        this.data = data;
        importFile = new JButton("Import");
        importFile.setSize(80, 20);
        exportFile = new JButton("Export");
        exportFile.setSize(80, 20);
        difficulty1 = new JButton("Easy");
        difficulty1.setSize(80, 20);
        difficulty2 = new JButton("Normal");
        difficulty2.setSize(80, 20);
        difficulty3 = new JButton("Hard");
        difficulty3.setSize(100, 20);
        if(data.whatDifficulty() == 0)
        {
            difficulty1.setEnabled(false);
        }
        else if(data.whatDifficulty() == 1)
        {
            difficulty2.setEnabled(false);
        }
        else
        {
            difficulty3.setEnabled(false);
        }
        
        backMain = new JButton("Main Menu");
        backMain.setSize(100, 20);
        titleMenu = new JLabel("Options");
        titleMenu.setHorizontalAlignment(JLabel.CENTER);
        importFileLabel = new JLabel("Import:");
        exportFileLabel = new JLabel("Export:");
        difficultyLabel = new JLabel("Difficulty:");
        importFileName = new JTextField(12);
        exportFileName = new JTextField(12);
        centerArea = new JPanel();
        centerArea.setLayout(new GridBagLayout());
        centerStage = new GridBagConstraints();
        bottomArea = new JPanel();
        
        Container optionsPanel = this.getContentPane();
        optionsPanel.setLayout(new BorderLayout());
        
        centerStage.gridx = 0;
        centerStage.gridy = 0;
        centerStage.weightx = 0.5;
        centerStage.weighty = 0.1;
        centerArea.add(importFileLabel, centerStage);
        
        centerStage.gridx = 1;
        centerStage.gridwidth = 2;
        centerArea.add(importFileName, centerStage);
        
        centerStage.gridx = 3;
        centerStage.gridwidth = 1;
        centerArea.add(importFile, centerStage);
        class importingTextFile implements ActionListener
        {
            public void actionPerformed(ActionEvent ae)
            {
                ImportExport imported = new ImportExport(importFileName.getText());
                try
                {
                  imported.importTxt();
                }
                catch(IOException e)
                {
                    String mema = null;
                } //https://stackoverflow.com/questions/17138207/calling-a-method-to-read-from-a-text-file-with-bufferedreader
                
                ArrayList<String> allCardFront = imported.getAllFront();
                ArrayList<String> allCardBack = imported.getAllBack();
                for(int i = 0; i < allCardFront.size(); i++)
                {
                    String text = "title";
                    if(text.equals(allCardFront.get(i)))
                    {
                        data.addDeck(allCardBack.get(i));
                        data.addDeckImports();
                    }
                    else
                    {
                        data.setIterator(data.numberOfDecks()-1);
                        data.getDeck().addCard(allCardFront.get(i), allCardBack.get(i));
                    }
                }
                importFileName.setText("");
                revalidate();
                repaint();
            }
        }
        importFile.addActionListener(new importingTextFile());
        
        centerStage.gridx = 0;
        centerStage.gridy = 1;
        centerArea.add(exportFileLabel, centerStage);
        
        centerStage.gridx = 1;
        centerStage.gridwidth = 2;
        centerArea.add(exportFileName, centerStage);
        
        centerStage.gridx = 3;
        centerStage.gridwidth = 1;
        centerArea.add(exportFile, centerStage);
        class exportingTextFile implements ActionListener
        {
            public void actionPerformed(ActionEvent ae)
            {
                ImportExport exported = new ImportExport(exportFileName.getText());
                for(int i = 0; i < data.numberOfDecks(); i++)
                {
                    data.setIterator(i);
                    exported.exportContent("title", data.getTitle());
                    Deck currentDeck = data.getDeck();
                    for(int j = 0; j < currentDeck.getSize(); j++)
                    {
                        Card currentCard = currentDeck.getCard(j);
                        exported.exportContent(currentCard.getFront(), currentCard.getBack());
                    }
                }
                try
                {
                    exported.exportTxt();
                }
                catch(IOException e)
                {
                    String mema = null;
                }
                exportFileName.setText("");
                revalidate();
                repaint();
            }
        }
        exportFile.addActionListener(new exportingTextFile());
        
        centerStage.gridx = 0;
        centerStage.gridy = 2;
        centerArea.add(difficultyLabel, centerStage);
        
        centerStage.gridx = 1;
        centerArea.add(difficulty1, centerStage);
        class easyDifficulty implements ActionListener
        {
            public void actionPerformed(ActionEvent ae)
            {
                data.changeDifficulty(0);
                difficulty1.setEnabled(false);
                difficulty2.setEnabled(true);
                difficulty3.setEnabled(true);
            }
        }
        difficulty1.addActionListener(new easyDifficulty());
        
        centerStage.gridx = 2;
        centerArea.add(difficulty2, centerStage);
        class normalDifficulty implements ActionListener
        {
            public void actionPerformed(ActionEvent ae)
            {
                data.changeDifficulty(1);
                difficulty1.setEnabled(true);
                difficulty2.setEnabled(false);
                difficulty3.setEnabled(true);
            }
        }
        difficulty2.addActionListener(new normalDifficulty());
        
        centerStage.gridx = 3;
        centerArea.add(difficulty3, centerStage);
        class hardDifficulty implements ActionListener
        {
            public void actionPerformed(ActionEvent ae)
            {
                data.changeDifficulty(2);
                difficulty1.setEnabled(true);
                difficulty2.setEnabled(true);
                difficulty3.setEnabled(false);
            }
        }
        difficulty3.addActionListener(new hardDifficulty());
        
        bottomArea.add(backMain);
        class backToMain implements ActionListener
        {
            public void actionPerformed(ActionEvent ae)
            {
                dispose();
            }
        }
        backMain.addActionListener(new backToMain());
        
        optionsPanel.add(titleMenu, "North");
        optionsPanel.add(centerArea, "Center");
        optionsPanel.add(bottomArea, "South");
    }
}
