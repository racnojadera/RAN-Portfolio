
/**
 * Contains an individual deck's information.
 *
 * @author Raymond Andrew C. Nojadera
 * @version December 8, 2018
 */

import java.util.*;
public class Deck
{
    private String deckName;
    private int frontBackIndicator;
    private ArrayList<Card> cardList = new ArrayList<Card>();
    
    /**
     * Constructs the deck.
     *
     * @param t contains the name of the deck.
     */
    public Deck(String t)
    {
        deckName = t;
        frontBackIndicator = 0;
    }

    /**
     * Adds a new card in the deck.
     *
     * @param f sets the value for the front of the card.
     * @param b sets the value for the back of the card.
     */
    public void addCard(String f, String b)
    {
        cardList.add(new Card(f, b));
    }
    
    /**
     * Removes a card at a certain location.
     *
     * @param i indicates the location of the card.
     */
    public void removeCard(int i)
    {
        cardList.remove(i);
    }
    
    /**
     * Gets the name of the deck.
     *
     * @return the deck name.
     */
    public String getTitle()
    {
        return deckName;
    }
    
    /**
     * Gets the card at a certain location.
     *
     * @param i indicates the location of the card.
     */
    public Card getCard(int i)
    {
        return cardList.get(i);
    }
    
    /**
     * Shuffles the arraylist of cards in the deck.
     */
    public void Shuffle()
    {
        Collections.shuffle(cardList); //https://stackoverflow.com/questions/1519736/random-shuffling-of-an-array
    }
    
    /**
     * Identifies the number of cards in the deck.
     *
     * @return the size of the deck.
     */
    public int getSize()
    {
        return cardList.size();
    }
    
    
}
