
/**
 * Write a description of class StudyDeck here.
 *
 * @author Raymond Andrew C. Nojadera
 * @version December 8, 2018
 */

import java.util.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class StudyDeckGUI extends JFrame
{
    // instance variables - replace the example below with your own
    private Database data;
    private JButton showFront, showBack, nextCard, backMain, checkAnswer;
    private JLabel deckName, frontContent, backContent;
    private JTextField identification;
    private JPanel centerArea, bottomArea;
    private GridBagConstraints bottomPanel;
    private Deck deckReplica;
    private int iterator;
    
    /**
     * Creates the study interface.
     *
     * @param data Gets the Database's values.
     */
    public StudyDeckGUI(Database data)
    {
        this.data = data;
        iterator = 0;
        showFront = new JButton("Show Front");
        showFront.setPreferredSize(new Dimension(100, 25));
        showFront.setEnabled(false);
        showBack = new JButton("Show Back");
        showBack.setPreferredSize(new Dimension(100, 25));
        nextCard = new JButton("Next Card");
        nextCard.setPreferredSize(new Dimension(100, 25));
        nextCard.setEnabled(false);
        backMain = new JButton("Main Menu");
        backMain.setPreferredSize(new Dimension(100, 25));
        checkAnswer = new JButton("Check");
        checkAnswer.setPreferredSize(new Dimension(100, 25));
        identification = new JTextField(10);
        if(data.whatDifficulty() == 0)
        {
            showFront.setVisible(true);
            showBack.setVisible(true);
            checkAnswer.setVisible(false);
            identification.setVisible(false);
        }
        else
        {
            showFront.setVisible(false);
            showBack.setVisible(false);
            checkAnswer.setVisible(true);
            identification.setVisible(true);
        }
        deckName = new JLabel(data.getTitle());
        deckName.setHorizontalAlignment(JLabel.CENTER);
        frontContent = new JLabel();
        frontContent.setHorizontalAlignment(JLabel.CENTER);
        backContent = new JLabel();
        backContent.setHorizontalAlignment(JLabel.CENTER);
        centerArea = new JPanel();
        centerArea.setLayout(new GridLayout(0,1));
        bottomArea = new JPanel();
        bottomArea.setLayout(new GridBagLayout());
        bottomPanel = new GridBagConstraints();
        deckReplica = data.cloneDeck();
        deckReplica.Shuffle();
        
        Container studyDeckGUI = this.getContentPane();
        studyDeckGUI.setLayout(new BorderLayout());
        
        Card current = deckReplica.getCard(iterator);
        frontContent.setText(current.getFront());
        backContent.setText(current.getBack());
        
        centerArea.add(frontContent);
        
        bottomPanel.gridx = 0;
        bottomPanel.gridy = 0;
        bottomPanel.weightx = 1;
        bottomPanel.weighty = 0.1;
        bottomArea.add(showFront, bottomPanel);
        class showCardFront implements ActionListener
        {
            public void actionPerformed(ActionEvent ae)
            {
                centerArea.remove(backContent);
                centerArea.add(frontContent);
                showFront.setEnabled(false);
                showBack.setEnabled(true);
                revalidate();
                repaint();
            }
        }
        showFront.addActionListener(new showCardFront());
        
        bottomArea.add(identification, bottomPanel);
        
        bottomPanel.gridx = 1;
        bottomArea.add(showBack, bottomPanel);
        class showCardBack implements ActionListener
        {
            public void actionPerformed(ActionEvent ae)
            {
                centerArea.remove(frontContent);
                centerArea.add(backContent);
                showFront.setEnabled(true);
                showBack.setEnabled(false);
                if(iterator < deckReplica.getSize()-1)
                {
                    nextCard.setEnabled(true);
                }
                
                revalidate();
                repaint();
            }
        }
        showBack.addActionListener(new showCardBack());
        
        
        bottomArea.add(checkAnswer, bottomPanel);
        class identificationCheck implements ActionListener
        {
            public void actionPerformed(ActionEvent ae)
            {
                if(data.whatDifficulty() == 1)
                {
                    JLabel remarks = new JLabel();
                    remarks.setHorizontalAlignment(JLabel.CENTER);
                    if(backContent.getText().equals(identification.getText()))
                    {
                        remarks.setText("Correct!");
                        centerArea.add(remarks);
                    }
                    else
                    {
                        remarks.setText("Wrong! Correct answer is " + backContent.getText() + ".");
                        centerArea.add(remarks);
                    }
                }
                else if(data.whatDifficulty() == 2)
                {
                    JLabel remarks = new JLabel();
                    remarks.setHorizontalAlignment(JLabel.CENTER);
                    if(backContent.getText().equals(identification.getText()))
                    {
                        remarks.setText("Correct!");
                        centerArea.add(remarks);
                        deckReplica.removeCard(iterator);
                    }
                    else
                    {
                        remarks.setText("Wrong!");
                        centerArea.add(remarks);
                        deckReplica.Shuffle();
                    }
                }
                checkAnswer.setEnabled(false);
                if(iterator < deckReplica.getSize())
                {
                    nextCard.setEnabled(true);
                }
                else if(iterator == deckReplica.getSize())
                {
                    nextCard.setEnabled(false);
                }
                revalidate();
                repaint();
            }
        }
        checkAnswer.addActionListener(new identificationCheck());
        
        bottomPanel.gridx = 0;
        bottomPanel.gridy = 1;
        bottomArea.add(nextCard, bottomPanel);
        class showNextCard implements ActionListener
        {
            public void actionPerformed(ActionEvent ae)
            {
                if(data.whatDifficulty() != 2)
                {
                    iterator += 1;
                }
                identification.setText("");
                showFront.setEnabled(false);
                showBack.setEnabled(true);
                checkAnswer.setEnabled(true);
                nextCard.setEnabled(false);
                Card current = deckReplica.getCard(iterator);
                frontContent.setText(current.getFront());
                backContent.setText(current.getBack());
                centerArea.removeAll();
                centerArea.add(frontContent);
                revalidate();
                repaint();
            }
        }
        nextCard.addActionListener(new showNextCard());
        
        bottomPanel.gridx = 1;
        bottomArea.add(backMain, bottomPanel);
        class backToMain implements ActionListener
        {
            public void actionPerformed(ActionEvent ae)
            {
                revalidate();
                dispose();
            }
        }
        backMain.addActionListener(new backToMain());
        
        //
        studyDeckGUI.add(deckName, "North");
        studyDeckGUI.add(centerArea, "Center");
        studyDeckGUI.add(bottomArea, "South");
    }
}
