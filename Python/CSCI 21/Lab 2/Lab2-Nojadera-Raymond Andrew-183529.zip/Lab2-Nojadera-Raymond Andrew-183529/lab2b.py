# Nojadera, Raymond Andrew C.
# 183529
# September 13, 2018
# I have not discussed the python language code in my program with anyone other than my instructor or the teaching assistants assigned to this course.
# I have not used python language code obtained from another student, or any other unauthorized source, either modified or unmodified.
# If any python language code or documentation used in my program was obtained from another source, such as a textbook or course notes, that has been clearly noted with a proper citation in the comments of my program.

def difference(a,b):
	if a > b:
		return a - b
	elif a < b:
		return b - a
	else:
		return 0
a = 0
b = 0
i = 0
pairs = int(input())
while i < pairs:
	a = int(input())
	b = int(input())
	print(difference(a, b))
	i += 1