# Nojadera, Raymond Andrew C.
# 183529
# September 13, 2018
# I have not discussed the python language code in my program with anyone other than my instructor or the teaching assistants assigned to this course.
# I have not used python language code obtained from another student, or any other unauthorized source, either modified or unmodified.
# If any python language code or documentation used in my program was obtained from another source, such as a textbook or course notes, that has been clearly noted with a proper citation in the comments of my program.

OutputValue = ''
Spaces = ' '
Ast = '*'
i = 0
j = 0
k = 0
l = 0
while True:
	userinput = int(input())
	if userinput < 0:
		break
	while l < userinput:
		i = userinput - l
		j = 2*l + 1
		k = i
		while i > 1:
			OutputValue = OutputValue + Spaces
			i -= 1
		while j > 0:
			OutputValue = OutputValue + Ast
			j -= 1
		while k > 1:
			OutputValue = OutputValue + Spaces
			k -= 1
		print(OutputValue)
		OutputValue = ""
		l += 1
	l -= 1
	while l > 0:
		i = userinput - l
		j = 2*l + 1
		k = userinput - l
		while i > 0:
			OutputValue = OutputValue + Spaces
			i -= 1
		while j > 2:
			OutputValue = OutputValue + Ast
			j -= 1
		while k > 0:
			OutputValue = OutputValue + Spaces
			k -= 1
		print(OutputValue)
		OutputValue = ""
		l -= 1
	print()