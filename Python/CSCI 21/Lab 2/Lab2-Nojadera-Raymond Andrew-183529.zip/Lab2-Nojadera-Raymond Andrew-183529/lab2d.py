# Nojadera, Raymond Andrew C.
# 183529
# Septebmer 13, 2018
# I have not discussed the python language code in my program with anyone other than my instructor or the teaching assistants assigned to this course.
# I have not used python language code obtained from another student, or any other unauthorized source, either modified or unmodified.
# If any python language code or documentation used in my program was obtained from another source, such as a textbook or course notes, that has been clearly noted with a proper citation in the comments of my program.

def negative(a):
	return a * -1

def add(a, b):
	return a + b

def maximum(a, b, c):
	if (a > b) and (a > c):
		return a
	elif (b > a) and (b > c):
		return b
	elif (c > a) and (c > b):
		return c

userinput = ''
a = 0
b = 0
c = 0

while True:
	userinput = input()
	if (userinput.lower() == 'negate'):
		a = int(input())
		print(negative(a))
	elif (userinput.lower() == 'add'):
		a = int(input())
		b = int(input())
		print(add(a, b))
	elif (userinput.lower() == 'maximum'):
		a = int(input())
		b = int(input())
		c = int(input())
		print(maximum(a, b, c))
	elif (userinput.lower() == 'stop'):
		break
