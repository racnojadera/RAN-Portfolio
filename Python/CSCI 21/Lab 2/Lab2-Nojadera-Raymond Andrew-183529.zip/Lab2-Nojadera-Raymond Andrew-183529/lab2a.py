# Nojadera, Raymond Andrew C.
# 183529
# Septebmer 13, 2018
# I have not discussed the python language code in my program with anyone other than my instructor or the teaching assistants assigned to this course.
# I have not used python language code obtained from another student, or any other unauthorized source, either modified or unmodified.
# If any python language code or documentation used in my program was obtained from another source, such as a textbook or course notes, that has been clearly noted with a proper citation in the comments of my program.

iterations = int(input())
j = 0
i = 0
while j < iterations:
	userinput = int(input())
	if i == 0:
		minimumvalue = userinput
		maximumvalue = userinput
	if (userinput > 1000) or (userinput < 1):
		break
	if userinput < minimumvalue:
		minimumvalue = userinput
	elif userinput > maximumvalue:
		maximumvalue = userinput
	j += 1
	i += 1
range = maximumvalue - minimumvalue
print("Maximum = " + str(maximumvalue))
print("Minimum = " + str(minimumvalue))
print("Range = " + str(range))

input()